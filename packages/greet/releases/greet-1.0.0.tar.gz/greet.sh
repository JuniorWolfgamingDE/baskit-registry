#!/usr/bin/env bash
# greet - demo script for baskit

set -euo pipefail

SCRIPT_VERSION="1.0.0"

show_help() {
  cat <<EOF
greet $SCRIPT_VERSION - demo script for baskit

USAGE
  greet [OPTIONS] [NAME]

OPTIONS
  -t, --time           Show current time with greeting
  -l, --lang LANG      Language (en, de)
  -v, --version        Show version
  -h, --help           Show this help

EXAMPLES
  greet Alice
  greet --time Bob
  greet --lang de Maria
EOF
}

TIME_ENABLED=false
LANG="en"
NAME="${1:-friend}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--time)
      TIME_ENABLED=true
      shift
      ;;
    -l|--lang)
      LANG="$2"
      shift 2
      ;;
    -h|--help)
      show_help
      exit 0
      ;;
    -v|--version)
      echo "You are running greet version $SCRIPT_VERSION."
      exit 0
      ;;
    -*)
      echo "Unknown option: $1" >&2
      show_help
      exit 1
      ;;
    *)
      NAME="$1"
      shift
      ;;
  esac
done

case "$LANG" in
  de)
    GREETING="Hallo"
    FAREWELL="Auf Wiedersehen!"
    ;;
  en|*)
    GREETING="Hello"
    FAREWELL="Goodbye!"
    ;;
esac

TIME_INFO=""
if [[ "$TIME_ENABLED" == true ]]; then
  TIME_INFO=" at $(date '+%H:%M:%S')"
fi

echo "$GREETING, $NAME!$TIME_INFO"
echo "$FAREWELL"
